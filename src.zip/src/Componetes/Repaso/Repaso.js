import React from 'react';

const Repaso = ({text}) => <h1>{text}</h1>;

export default Repaso;
